# Wild Wonders v8 · Veo 3.1 Lite → YouTube y TikTok

Exportación del workflow de 39 nodos consultado el 24 de septiembre de 2026. Incluye dos notas. Se entrega inactivo, sin credenciales, tokens, historial, datos de ejecución ni identificadores de tabla de la instalación de origen.

## Qué hace

Kimi K3 mediante Ollama escribe una narración en inglés y un storyboard de cuatro tomas; Nemotron 3 Super vía OpenRouter es respaldo. El validador evita repetir especies o géneros. Veo 3.1 Lite genera cuatro clips de 8 segundos a 720×1280 mediante Kie.ai. Se usan los primeros 7 segundos de cada clip: 28 segundos finales. ffmpeg concatena sin audio ambiente y añade narración Gemini 2.5 Pro TTS (Charon) y subtítulos. YouTube recibe el video público. TikTok intenta envío privado, con alternativa de borrador si rechaza la app no auditada.

La ejecución de referencia duró 11 min 24 s, produjo 27.97 segundos a 720×1280 y terminó en TikTok con SEND_TO_USER_INBOX (borrador). No garantiza el mismo tiempo ni publicación pública en TikTok.

## 1. Preparar archivos

Requiere Docker Compose, Node dentro de la imagen n8n y ffmpeg/ffprobe estáticos compatibles con la arquitectura del servidor y con libass/subtitles. Obtén los binarios de una distribución confiable enlazada por https://ffmpeg.org/download.html y respeta su licencia. Colócalos como `tools/ffmpeg` y `tools/ffprobe`; hazlos ejecutables. Copia la fuente Liberation Sans en `tools/fonts/`, incluyendo su licencia si redistribuyes la fuente. Los binarios y fuentes NO están incluidos en este ZIP.

Crea las carpetas `files/`, `tools/fonts/` y `tiktok/`. La carpeta `files/` debe permitir escritura al usuario node (UID 1000) del contenedor. Usa una versión compatible y fija de n8n en producción; el compose utiliza latest como punto de partida. Este flujo usa Execute Command: revisa los comandos antes de importarlo en un servidor compartido.

## 2. Levantar n8n

Ejecuta `docker compose up -d`, abre http://localhost:5678 y crea tu cuenta. Este compose publica solo en localhost. No sustituye ni modifica una instalación existente.

## 3. Crear historial

Crea una Data Table llamada `wild_wonders_historial` con estas columnas de texto:

- fecha
- especie
- titulo
- categoria
- comportamiento
- dato_central
- costo_usd
- modelo
- youtube_id

Importa `wild-wonders-v8.json`. En Leer Historial, Guardar Historial y Registrar Subida selecciona tu propia tabla, sustituyendo REEMPLAZAR_ID_TABLA.

## 4. Conectar servicios

- Kie.ai: credencial Header Auth, nombre `Authorization`, valor `Bearer TU_API_KEY`; asígnala a los nodos que usan httpHeaderAuth.
- Ollama: credencial con la URL accesible desde Docker y acceso a `kimi-k3:cloud`; si Ollama corre en el host, usa la dirección apropiada para tu instalación, por ejemplo host.docker.internal:11434. Requiere acceso al modelo cloud.
- OpenRouter: tu propia API key en el nodo Nemotron de respaldo. La disponibilidad de modelos gratuitos puede cambiar.
- YouTube: habilita YouTube Data API v3 y configura OAuth2 en n8n para tu propio canal. El nodo Upload a video está configurado para publicar; comprueba esa visibilidad antes de ejecutar.
- TikTok: registra tu app, configura los permisos Content Posting y completa el flujo OAuth del propietario. El script espera `tiktok/app.json` con client_key/client_secret y `tiktok/token.json` con access_token, refresh_token, expires_in y obtained_at (segundos Unix). No se incluyen credenciales ni un asistente OAuth. No subas esos archivos a Git. El volumen TikTok permite escribir el token renovado, mientras los scripts quedan de solo lectura.

Si todavía no vas a usar TikTok, desconecta la salida de Registrar Subida hacia Preparar TikTok en tu copia del workflow. YouTube y el registro del historial quedan como final del recorrido. No ejecutes la cadena TikTok sin su configuración.

## 5. Probar y programar

La ejecución manual consume saldo en Kie.ai y sube contenido a los destinos configurados. Revisa credenciales, prompt y visibilidad antes de pulsar Execute workflow. Verifica archivos, subtítulos, historial y estado final de TikTok. Un borrador requiere completar la publicación desde la app de TikTok.

El horario configurado es lunes a viernes a las 10:00, zona America/Guatemala. El JSON se entrega INACTIVO; actívalo solo después de la prueba.

## Costos de referencia

La nota del workflow del 23/09/2026 registra 30 créditos = USD 0.15 por clip de Veo Lite. Cuatro clips: USD 0.60; voz aproximadamente USD 0.01; total aproximadamente USD 0.61. Es un cálculo documentado, no una tarifa garantizada ni una factura de cada corrida. No incluye servidor, modelo de guion, reintentos ni otros servicios. Verifica los precios en tus cuentas.

## Personalización

Edita Preparar Brief para categorías y Director de Cine para tono/nicho. Mantén el contrato de cuatro tomas y los campos del parser, o adapta también Validar Nuevo, Storyboard → Tomas, Unir Tomas y el montaje. Cambiar de proveedor de video requiere adaptar petición, respuesta y polling, no solo el nombre del modelo.
